package com.bank.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.bank.entity.AccountMaster;
import com.bank.entity.Admin;
import com.bank.entity.Customer;
import com.bank.entity.FundTransfer;
import com.bank.entity.Payee;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;

@Repository
public class BankRepositoryImpl implements IBankRepository {

	@PersistenceContext
	private EntityManager entityManager;

	public UserTable check(UserTable user) {
		String q="SELECT b FROM UserTable b WHERE b.userId=:puid AND b.loginPassword=:ppass";
		TypedQuery<UserTable> query=entityManager.createQuery(q,UserTable.class);
		query.setParameter("puid", user.getUserId());
		System.err.println(user.getUserId());
		query.setParameter("ppass",user.getLoginPassword());
		return query.getSingleResult(); 
		
		
	}
@Override
	public AccountMaster getAccountBalance(long accId) {
		String q="SELECT g FROM AccountMaster g WHERE g.accountId=:paccblnce";
		TypedQuery<AccountMaster> query2=entityManager.createQuery(q,AccountMaster.class);
		query2.setParameter("paccblnce",accId);
		return  query2.getSingleResult();
	}
@Override
public int getChangeAddress(long accId, String cadd) {
	String q = "UPDATE Customer c SET c.customerAddress=:padd WHERE c.accountId=:pId";
	
	Query query=entityManager.createQuery(q);
	query.setParameter("pId", accId);
	query.setParameter("padd",cadd);
	return  query.executeUpdate(); 
}

@Override

public UserTable checkSecret(String secret,int uid) {
 
String q1="SELECT u FROM UserTable u WHERE u.secretQuestion=:secret AND u.userId=:pid";
 
TypedQuery<UserTable> query1=entityManager.createQuery(q1,UserTable.class);
 
query1.setParameter("secret",secret);
 
query1.setParameter("pid", uid);
 
return query1.getSingleResult();

}
 
@Override
 
public int changePassword(int userId, String pass) {
 
String q1 = "UPDATE UserTable u SET u.loginPassword=:plpw WHERE u.userId=:pId"; 
 
Query query=entityManager.createQuery(q1);
 
query.setParameter("pId", userId);
 
query.setParameter("plpw", pass); 
 
return query.executeUpdate(); 

}



@Override
 
public UserTable checkPassWord(UserTable user) {
 
String q="SELECT b FROM UserTable b WHERE b.secretQuestion=:psq";
 
TypedQuery<UserTable> query=entityManager.createQuery(q,UserTable.class);
 
query.setParameter("psq", user.getSecretQuestion());
 
System.err.println(user.getSecretQuestion());

 
return query.getSingleResult();

}
 


@Override
public int getChangeMobNum(long accId, String cmob) {
	String q1 = "UPDATE Customer c SET c.customerMobNum=:pmob WHERE c.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("pmob", cmob);
	return  query.executeUpdate(); 
}
@Override
public int getChangePassWord(long accId, String cpw) {
	String q1 = "UPDATE UserTable u SET u.loginPassword=:plpw WHERE u.accountId=:pId";
	Query query=entityManager.createQuery(q1);
	query.setParameter("pId", accId);
	query.setParameter("plpw", cpw);
	return  query.executeUpdate(); 
}
@Override
public List<Transactions> loadAllTransactions() {
	TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e",Transactions.class);
	
	return query.getResultList();
}


@Override
	public int login(int adminId,String password)
	{
		TypedQuery<Integer> query=entityManager.createQuery("SELECT a.adminId FROM Admin a where a.adminId=:padminId and a.password=:ppassword",Integer.class);
		query.setParameter("padminId", adminId);
		query.setParameter("ppassword", password);
		
		try {
			int adminId1=query.getSingleResult();
			int loggeduser=adminId1;
			return loggeduser;	
		} catch (NoResultException e) {
			int loggeduser=0;
			return loggeduser;	
			
	}
	}

	@Override
	public long add(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		//System.out.println(customer.getAccountId());
		return customer.getAccountId();
	}
	@Override
	public List<Transactions> loadDateTransactions(String dateOfTransaction) {
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e where e.dateOfTransaction=:ddate",Transactions.class);
		query.setParameter("ddate",dateOfTransaction);
		return query.getResultList();
	}
	@Override
	public List<Transactions> loadMonthTransactions(String monthTransaction) {
	
		System.out.println(monthTransaction);
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e WHERE SUBSTRING(e.dateOfTransaction, 4, 9) = :mmonth",Transactions.class);
		query.setParameter("mmonth",monthTransaction);
		List<Transactions> list=query.getResultList();
		return list;
		
	}
	@Override
	public List<Transactions> loadYearTransactions(String yearTransaction) {
		System.out.println(yearTransaction);
		TypedQuery<Transactions> query=entityManager.createQuery("SELECT e FROM Transactions e WHERE SUBSTRING(e.dateOfTransaction, 8, 9) = :yyear",Transactions.class);
		query.setParameter("yyear",yearTransaction);
		List<Transactions> list=query.getResultList();
		System.out.println(list);
		return list;
	}
	

@Override
 
public int getservId(long accId) {
 
TypedQuery<Integer> query = entityManager.createQuery("select s.serviceId from ServiceTracker s where s.accountId=:pId", Integer.class);
 
query.setParameter("pId", accId);
 
int id= query.getSingleResult(); 
 
return id;

}
 
@Override
 
public String getServiceTracker(int serviceId) {
 
TypedQuery<String> query = entityManager.createQuery("select s.serviceStaus from ServiceTracker s where s.serviceId=:pId", String.class);
 
query.setParameter("pId", serviceId);
System.out.println(serviceId);
String status= query.getSingleResult(); 
 
return status ;

}

@Override
public int getCheckBook(long accId, String sd, String ss,String dt) {

	String q = "Insert into ServiceTracker (accountId,serviceDescription,serviceStaus,serviceRequestDate) VALUES (:pId,:psd, :pss,:pdt)";
	ss="active";
	
	System.out.println("AccId:st"+accId);
	 
	System.out.println("sd:st"+sd);
	 
	System.out.println("ss:st"+ss);
	
	System.out.println("dt:dt"+dt);
	 
	Query query=entityManager.createQuery(q);
	 
	query.setParameter("pId", accId);
	
	query.setParameter("pdt", dt);
	
	query.setParameter("psd",sd);
	
	query.setParameter("pss", ss); 
	
	
	 
	return query.executeUpdate(); 

} 

@Override
 
public List<Transactions> loadMiniStatement(long accId) {
 
TypedQuery<Transactions> query = entityManager.createQuery("SELECT h FROM Transactions h WHERE h.accountId=:paId ",Transactions.class);
 
query.setParameter("paId", accId);
 
return query.getResultList();

}


@Override
 
public List<Transactions> loadDetailedStatement(String startDate,String endDate,long accId) {
 
TypedQuery<Transactions> query = entityManager.createQuery("SELECT h FROM Transactions h WHERE h.dateOfTransaction BETWEEN:startDate and :endDate AND h.accountId=:paId ORDER BY h.dateOfTransaction DESC",Transactions.class);
 
query.setParameter("paId", accId);
 
query.setParameter("startDate", startDate);
 
query.setParameter("endDate", endDate);
 
System.out.println(query.getResultList());
 
return query.getResultList();

}

@Override
public int add(UserTable usertable) {
	entityManager.persist(usertable);
	entityManager.flush();
	System.out.println(usertable);
	System.out.println(usertable.getUserId());
	return usertable.getUserId();
}


//transccations
LocalDateTime myDateObj = LocalDateTime.now(); 
DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
 String formattedDate = myDateObj.format(myFormatObj);

public List<Payee> getAllUser(long accountId) throws BankingException{

	try{
	TypedQuery<Payee>  query = entityManager.createQuery("SELECT p FROM Payee p WHERE p.accountId = :accno",Payee.class);
			
			query.setParameter("accno",accountId);
	
	return query.getResultList();
	}
	catch(Exception e){
		return null;
	}
	
}

@Override
public boolean fundTransfer(long accountId,long payeraccno, double amount,String paymtd) throws BankingException {
	
	AccountMaster accMasterpayee=entityManager.find(AccountMaster.class, accountId);
	AccountMaster accMasterpayer=entityManager.find(AccountMaster.class, payeraccno);
	if(accMasterpayee!=null){
		accMasterpayee.setAccountBalance(accMasterpayee.getAccountBalance()+amount);
		accMasterpayer.setAccountBalance(accMasterpayer.getAccountBalance()-amount);
		double availBalancepayee = accMasterpayee.getAccountBalance();
		double availBalancepayer = accMasterpayer.getAccountBalance();
		LocalDateTime myDateObj = LocalDateTime.now(); 
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MMM-yy");
		 String formattedDate = myDateObj.format(myFormatObj);
		 int id=(int) (Math.random()*1000000);
		 
		 /* transaction table update */
		Transactions transaction = new Transactions();
		transaction.setAccountId(accountId);
		transaction.setDateOfTransaction(formattedDate);
		transaction.setTransactionAmount(amount);
		transaction.setTransactionDesc("Credit");
		transaction.setTransactionId(id);
		transaction.setTransactionType(paymtd);
		
		
		/* fund transfer table update */
		FundTransfer fundTransfer=new FundTransfer();
		fundTransfer.setDateOfTransfer(formattedDate);
		fundTransfer.setFundId(id);
		fundTransfer.setPayeeAccId(accountId);
		fundTransfer.setSenderAccountNum(payeraccno);
		fundTransfer.setTransferAmt(amount);
		
		entityManager.persist(transaction);
		entityManager.persist(fundTransfer);
		
		/*account master for payer and payee update*/ 
		
		String str1="UPDATE AccountMaster AS c SET c.accountBalance=:pname WHERE c.accountId=:pno";
		Query query3=entityManager.createQuery(str1);
		query3.setParameter("pname",availBalancepayer-amount);
		query3.setParameter("pno", payeraccno); 
		query3.executeUpdate();
				
		Query query4=entityManager.createQuery(str1);
		query4.setParameter("pname",availBalancepayee+amount);
		query4.setParameter("pno",accountId); 
		query4.executeUpdate();
		
		entityManager.flush();
		return true;
	}
	return false;
	
}

@Override
public boolean fundPayer(long accountId, double amount) throws BankingException {

	
	AccountMaster accMaster=entityManager.find(AccountMaster.class, accountId);
	
	if(accMaster!=null){
		accMaster.setAccountBalance(accMaster.getAccountBalance()-amount);
		double availBalance = accMaster.getAccountBalance();
		if(availBalance<amount)
			return false;
		else{
			
			return true;  
		}
	}
	return false;
	}

@Override
public boolean addPayee(Payee payee) throws BankingException {
	entityManager.persist(payee);
	entityManager.flush();
	System.out.println(payee.getAccountId());
	return true;
	
}



@Override
public boolean checkPayee(long paccId) throws BankingException {
	try{
	AccountMaster accMastercheck=entityManager.find(AccountMaster.class,paccId);
	if(accMastercheck!=null){
		return true;
	}else{
		return false;
	}
	}catch(Exception e){
		throw new BankingException(e.getMessage());
	}
	
}



	
	
	
	
	
 

}
