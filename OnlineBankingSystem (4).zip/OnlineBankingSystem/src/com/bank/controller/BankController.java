package com.bank.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.jboss.security.auth.spi.Users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;














import org.springframework.web.servlet.ModelAndView;

import com.bank.entity.AccountMaster;
import com.bank.entity.Admin;
import com.bank.entity.Customer;
import com.bank.entity.Payee;
import com.bank.entity.ServiceTracker;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;
import com.bank.service.BankService;
import com.bank.service.IBankService;

@Controller
public class BankController {
	@Autowired
	public IBankService bankService;
	
	 
	static int userId;
	static long accId;
	static int adminid;
	static String dateOfTransaction;
	static int serviceId;
	static UserTable user1;

	//shows the homepage
	@RequestMapping("/index")
	public String showIndex(Model model){
		return "index";
	}
	
	//login page
	@RequestMapping(value= "/loginPage")
	public String showLoginPage(Model model){
		//model.addAttribute("account", account);
	 model.addAttribute("UserTable",new UserTable());
		return "loginPage";
	}
	
//******************************************USER SignUp******************************************//
	  @RequestMapping("/usersignup")
	    public String saves(Model model){
	    	model.addAttribute("useraccount",new UserTable());
	    	return "usersignup";
	    }
	    
	    @RequestMapping(value="/usersignup2")
	    public String userSignUp(@ModelAttribute("useraccount")UserTable usertable, Model model){
	    	
	    	int userids =bankService.add(usertable);
	    	//usertable =  bankService.add(usertable);
	    	/*if(userid!=0){
	    	
    		return "error";
	    	}*/
    		
	    	/*else{*/
	    		
	    		model.addAttribute("userId", userids);
	    		return "usersignup2";
	    	}
	    
	    	
	    	/*int userid=0;
	    	  userid =  bankService.add(usertable);
	    	  
	    	  
	    	*/
	    	
	    
	    
	    
	    @RequestMapping(value="/forgotPassword")
	    
	    public String forgotPass(Model model){
	     
	    model.addAttribute("UserTable",new UserTable());
	     
	    return "forgotPassword";

	    }
	     
	    @RequestMapping(value="/forgotPassword1")
	     
	    public String forgotPassword(@ModelAttribute("UserTable")UserTable user,Model model){
	     
	    String secretQ=user.getSecretQuestion();
	     
	    userId=user.getUserId();

	     
	    model.addAttribute("changePassWord",new UserTable()); 
	     
	    model.addAttribute("secret",bankService.checkSecret(secretQ,userId)); 
	     
	    return "changePassWord";

	    }

	     
	    @RequestMapping(value="successPassWord1")
	     
	    public String password(Model model,@ModelAttribute("changePassWord")UserTable user){
	     
	    String pass=user.getLoginPassword();
	     
	    model.addAttribute("changePassWord",bankService.getpassword(userId,pass));
	     
	    return "successPassWord";

	    }

	    	
	    	
	   
	
//####################################### ACCOUNT HOLDER ##########################################//	
//*************************************ACCOUNTID***************************************************//
    @RequestMapping(value="/accountHolder")
		public String login(@ModelAttribute("accountHolder")UserTable user,@RequestParam("userId")int uid,Model model){
			userId=uid;
	       model.addAttribute("bank",bankService.check(user));
		   model.addAttribute("message","successfully loggedin!");
		   user=bankService.check(user);
		   UserTable user1=   bankService.check(user);
		accId=user1.getAccountId();
		  System.out.println(accId);    
		 
		    return "accountHolder";
		} 

    
//*************************************ACCOUNT BALANCE**********************************************//  
   
    @RequestMapping(value="/accountBalance")
      public String  showaccountbalance(Model model){
    	 model.addAttribute("accbalance",bankService.getAccountBalance(accId));
    return "accountBalance";
    	  
      }
      
    
//*************************  CHANGE ADDRESSS ***********************************************//
    @RequestMapping(value= "/changeAddress")
	public String showAddressPage(Model model){
		model.addAttribute("customer",new Customer());
		return  "changeAddress";
	}
    
    
      @RequestMapping(value="/successAdd")
    public String  showchangeAddress(Model model,@ModelAttribute("changeAddress")Customer cust){
    	String cadd=cust.getCustomerAddress();
    model.addAttribute("changeAddress",bankService.getChangeAddress(accId,cadd));
    return "successAdd";
  	  
    }
      
      
//********************** CHANGE PHONE NUMBER**************************************************//
     @RequestMapping(value= "/changePhone")
  	public String showchangePhone(Model model){
  		model.addAttribute("customer",new Customer());
  		return  "changePhone";
  	}

    @RequestMapping(value="/successPhone")
    public String showchangePhone(Model model,@ModelAttribute("changePhone")Customer cus){
    	String cmob=cus.getCustomerMobNum();
    	model.addAttribute("changePhone",bankService.getChangeMobNum(accId,cmob));
        return "successPhone";
  	  
    }
 
//*********************************UPDATE PASSWORD*********************************************//
     





    
@RequestMapping(value= "/changePassword1")
 
public String showchangePassWord(Model model){
 
model.addAttribute("changePassword1",new UserTable());
 
return "changePassword1";

}

 
@RequestMapping(value="/successPassWord")
 
public String showchangePassWord(Model model,@ModelAttribute("changePassword1")UserTable ut){
 
String cpw=ut.getLoginPassword();
 
model.addAttribute("changePassword1",bankService.getChangePassWord(accId,cpw));
 
return "successPassWord";


}

    
    

//*****************************viewMiniStatement************************************************//
   
    	@RequestMapping("/viewStatement")
    	    public String viewStatement() {
    	       return "viewStatement";

    	    }    
    	    
    	@RequestMapping("/viewMiniStatement")
    	 
    	public String viewMiniStatement() {
    	 
    	return "miniStatement";

    	}

    	 
    	@RequestMapping(value="miniStatement")
    	 public String getMiniStatement(Model model){
    	 model.addAttribute("bankList", bankService.loadMiniStatement(accId));
    	 model.addAttribute("miniStatement", new Transactions());
    	 return "miniStatement";

    	} 
    	 


@RequestMapping("/detailedStatement")

public String viewDetailedStatement(Model model) {
 
//model.addAttribute("detailsList",new Transactions());
 
return "detailedStatement";


}

 
@RequestMapping(value="detailedStatement1")
 
public String getDetailedStatement(@RequestParam("startDate")String startDate,@RequestParam("endDate")String endDate ,Model model){

 
System.out.println(startDate);
 
System.out.println(endDate);
 
model.addAttribute("detailsList", bankService.loadDetailedStatement(startDate, endDate,accId));
 
model.addAttribute("detailedStatement", new Transactions());

 
return "detailedStatement";

}



//****************************cheque book*********//



 
@RequestMapping(value= "/chequeBook")
 
public String showCheckBookRequest(Model model){
	model.addAttribute("acIdForJsp", accId);
	System.out.println("ac is "+accId);
model.addAttribute("ServiceTracker",new ServiceTracker());
 
return "chequeBook";

}

 


@RequestMapping(value="/successCheckBook")
 
public String showCheckBookRequest(Model model,@ModelAttribute("checkBook")ServiceTracker st){
 
String sd= st.getServiceDescription();
 
String ss=st.getServiceStaus();

String dt=st.getServiceRequestDate();

model.addAttribute("checkBook",bankService.getCheckBook(accId,sd,ss,dt));
model.addAttribute("serviceId",bankService.getservId(accId));
 
return "successCheckBook";

} 
 

//*****************************request tracker************//


@RequestMapping(value= "/serviceTracker")
 
public String showServiceTracker(Model model){
 
model.addAttribute("ServiceTracker",new ServiceTracker());
 
return "serviceTracker";

}
 
@RequestMapping(value="/successService")
 
public String login(@ModelAttribute("successService")ServiceTracker st,@RequestParam("ser")String sid,Model model){
 
serviceId= Integer.parseInt(sid); 
 
model.addAttribute("serviceTracker", bankService.getServiceTracker(serviceId));
 
return "successService";

}
 


////////////////////////////////////FUND transfer/////////////////////////////////////////////////////////



@RequestMapping("/userFundTransfer")
public ModelAndView userfundTransfer() {

	ModelAndView mv=null;
	
	try {
		List<Payee> userList = new ArrayList<Payee>();
		userList = bankService.getAllUser(accId);
		if(userList==null){
			mv=new ModelAndView("addPayee","userList",null);
		}else{
		mv = new ModelAndView("fundTransferPage","userList",userList);
		}
	} catch (BankingException e) {
		
	
	}
	return mv;
}

  //LINK FROM fund transferpage 				
@RequestMapping("/fundTransfer")
public ModelAndView fundTransfer(@RequestParam("accno") long accno, @RequestParam("paymtd") String paymtd,@RequestParam double amt) {

	ModelAndView mv=null;
	
	try {
		List<Payee> userList = new ArrayList<Payee>();
		userList = bankService.getAllUser(accId);
		if(accno==-1){
			mv = new ModelAndView("fundTransferPage", "userList",userList);
			mv.addObject("errmsg","Please select a payee!!!");
		}
		else{
			if (bankService.fundPayer(accId, amt)) {

				bankService.fundTransfer(accno,accId, amt,paymtd);
				
				mv = new ModelAndView("fundTransferPage", "userList",userList);
				mv.addObject("flag", true);
				mv.addObject("msg", "money transferred successfully!!!");

			} else {
				mv = new ModelAndView("fundTransferPage");
				mv.addObject("errmsg","transfer amount should be less than available balance");

			}
		}
	} catch (BankingException e) {
		mv = new ModelAndView("fundTransferPage");
		mv.addObject("errmsg", "transfer amount should be less than available balance");
	
	}
	return mv;
}

 //link from fundTransfer page.jsp			
@RequestMapping("/addPayee")
public ModelAndView addPayee() {

	ModelAndView mv=new ModelAndView("addPayee");
	return mv;
}
// link from payee.jsp 

@RequestMapping("/addPayeeDetails")
public ModelAndView addPayeeDetails(@RequestParam long paccId, @RequestParam String pname) {

	ModelAndView mv=null;
	
	try {
		Payee payee = new Payee();
		payee.setPayeeAccId(paccId);
		payee.setNickName(pname);
		System.out.println(accId);
		if(paccId!=accId){
		if (bankService.checkPayee(paccId)) {
			payee.setAccountId(accId);
			if (bankService.addPayee(payee)) {
				mv=new ModelAndView("addPayee");
				mv.addObject("flag",true);
				mv.addObject("msg","payee has been added successfully!!!");
				
			}

			else {
				mv = new ModelAndView("addPayee");
				mv.addObject("errmsg", "payee not added");
				
			}
		} else {
			mv = new ModelAndView("addPayee");
			mv.addObject("errmsg","No User available with this payee account Id");
			
		}
		}
		else{
			mv = new ModelAndView("addPayee");
			mv.addObject("errmsg","User cannot add himself as payee");
		}
	} catch (BankingException e) {
		
		mv = new ModelAndView("addPayee");
		mv.addObject("errmsg","No payee available with this payee account Id");
	}
	return mv;
}
 
/////////////////////////////////////////////////////////////////////////////////////////////







 



 





 //####################################### ADMIN ##########################################//	
    
//***************************************ADMIN LOGIN*************************************************//
    @RequestMapping("/adminlogin")
    public String dummy1(Model model){
    	model.addAttribute("login",new Admin());
    	return "adminlogin";
    } 
//********************************FOR CREATING NEW ACCOUNT***********************************************//
    @RequestMapping("/createaccount")
    public String save(Model model){
    	model.addAttribute("accountType",new String[]{"savingsaccount","currentaccount"});
    	model.addAttribute("createaccounts",new Customer());
    	return "createaccount";
    }
    
    @RequestMapping(value="/createaccount2")
    public String createAccount(@ModelAttribute("createaccounts")@Valid Customer customer,BindingResult result, Model model){
    	long account_Id=0;
    	if(result.hasErrors())
    	{
    		System.out.println("error");
    		return "error";
    	}
    	else
    	{
    		account_Id =  bankService.add(customer);
    		model.addAttribute("accountId", account_Id);
    		return "createaccount1";
    	} 
    }
    	
    	
    @RequestMapping("/adminsuccess")
     	public String adminLogin(@RequestParam("adminId") int adminId,
     			@RequestParam("password") String password,@ModelAttribute("login") Admin admin ,Model model) 
    	{
    	int adminId1=bankService.login(adminId, password);
    	if(adminId1==0)
    	{
    		model.addAttribute("message","wrong credentials.......try again");
    		return "error";
    	}
    	else
    	{
    		model.addAttribute("message","login successful");
    		return "adminsuccess";
    	}	
    	} 
    	  	
//*************************************All TRANSACTIONS**********************************************//  
    	 @RequestMapping("/alltransactions")
    	    public String transactions(Model model){
    	    	model.addAttribute("transactionList",bankService.loadAllTransactions());
    	    	model.addAttribute("transaction",new Transactions());
    	    	return "alltransactions";
    	    }
    	//To transactions page 
    	 @RequestMapping("/transactions")
    	 public String tranactions(Model model){
    		 return "transactions";
    	 }
    	 
    	 
//*************************************DATE WISE TRANSACTIONS**********************************************//      	
    	 @RequestMapping("/datetransactions")
  	    public String date(Model model){
  	    	model.addAttribute("transaction",new Transactions());
  	    	return "datetransactions";
  	    }
    	 
    	 
    	 @RequestMapping("/datetransactions1")
 	    public String dates(@RequestParam("dateofTransaction")String dateOfTransaction, Model model){
 	    	System.out.println(dateOfTransaction);
    		 model.addAttribute("transactionList",bankService.loadDateTransactions(dateOfTransaction));
    		 model.addAttribute("transaction",new Transactions());
    		 List<Transactions> list=bankService.loadDateTransactions(dateOfTransaction);
     		 System.err.println(list);
 	    	return "datewisetransactions";
 	    }
//*************************************MONTH WISE TRANSACTIONS**********************************************//      	 
    	 @RequestMapping("/monthtransactions")
   	    public String month(Model model){
   	    	model.addAttribute("transaction",new Transactions());
   	    	return "monthtransactions";
   	    }
    	 
    	@RequestMapping("/monthtransactions1")
  	    public String months(@RequestParam("monthTransaction")String monthTransaction, Model model){
  	    	System.out.println(monthTransaction);
     		 model.addAttribute("transactionList",bankService.loadMonthTransactions(monthTransaction));
     		 model.addAttribute("transaction",new Transactions());
  	    	return "monthlytransactions";
  	    }
    	
//*************************************YEAR WISE TRANSACTIONS**********************************************//    	
    	 @RequestMapping("/yeartransactions")
    	    public String year(Model model){
    	    	model.addAttribute("transaction",new Transactions());
    	    	return "yeartransactions";
    	    }
    	
    	
    	@RequestMapping("/yeartransactions1")
  	    public String years(@RequestParam("yearTransaction")String yearTransaction, Model model){
      		 model.addAttribute("transactionList",bankService.loadYearTransactions(yearTransaction));
     		 model.addAttribute("transaction",new Transactions());
     		
  	    	return "yearlytransactions";
  	    }
    
}


