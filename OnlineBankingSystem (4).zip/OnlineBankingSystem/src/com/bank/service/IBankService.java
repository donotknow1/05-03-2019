package com.bank.service;



import java.util.List;

import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.Payee;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;

public interface IBankService {
	
public UserTable check(UserTable user) ;

public AccountMaster getAccountBalance(long accId);

public int  getChangeAddress(long accId, String cadd);

public int getChangeMobNum(long accId,String cmob);

public int getChangePassWord(long accId, String cpw);

public long add(Customer customer);

public int add(UserTable usertable);

public int login(int adminId, String password);

public UserTable checkPassWord(UserTable user);

public UserTable checkSecret(String secret,int uid);

public int getpassword(int userId, String pass);

public List<Transactions> loadAllTransactions();

public List<Transactions> loadDateTransactions(String dateOfTransaction);

public List<Transactions> loadMonthTransactions(String monthTransaction);

public List<Transactions> loadYearTransactions(String yearTransaction);

public List<Transactions> loadMiniStatement(long accId);

public List<Transactions> loadDetailedStatement(String startDate,String endDate,long accId);



public int getservId(long accId);

public int getCheckBook(long accId, String sd, String ss,String dt);



//Transfer
public String getServiceTracker(int serviceId);

/**/
public List<Payee> getAllUser(long accountId) throws BankingException;

/**/
public boolean fundTransfer(long accno,long payeraccno, double amount,String paymtd) throws BankingException;

/**/
public boolean fundPayer(long accountId, double amount) throws BankingException;

/**/
public boolean addPayee(Payee payee) throws BankingException;

/**/
public boolean checkPayee(long paccId) throws BankingException;

}
