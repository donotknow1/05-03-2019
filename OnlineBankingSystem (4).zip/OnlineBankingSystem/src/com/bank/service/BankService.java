package com.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dao.IBankRepository;
import com.bank.entity.AccountMaster;
import com.bank.entity.Customer;
import com.bank.entity.Payee;
import com.bank.entity.Transactions;
import com.bank.entity.UserTable;
import com.bank.exception.BankingException;

@Service
@Transactional
public class BankService implements IBankService {
	@Autowired
	private IBankRepository bankRepository;

	public UserTable check(UserTable user) {
		// TODO Auto-generated method stub
		return bankRepository.check(user); 
	}


	@Override
	public AccountMaster getAccountBalance(long accId) {
		// TODO Auto-generated method stub
		return bankRepository.getAccountBalance(accId);
	}


	@Override
	public int getChangeAddress(long accId, String cadd) {
		return bankRepository.getChangeAddress(accId, cadd);
	}


	@Override
	public int getChangeMobNum(long accId,String cmob) {
		return bankRepository.getChangeMobNum(accId, cmob);
	}


	@Override
	public int getChangePassWord(long accId, String cpw) {
		return bankRepository.getChangePassWord(accId, cpw);
	}


	@Override
	public List<Transactions> loadAllTransactions() {
		// TODO Auto-generated method stub
		return bankRepository.loadAllTransactions();
	}


	

	@Override
	public long add(Customer customer) {
		
		return bankRepository.add(customer);
	}


	@Override
	public int login(int adminId, String password) {
		
		return bankRepository.login( adminId,password);
	}
	public UserTable checkPassWord(UserTable user) {
		 
	
		 
		return bankRepository.checkPassWord(user); 

		}
	@Override
	public UserTable checkSecret(String secret, int uid) {
		return bankRepository.checkSecret(secret,uid);
	}
	 
		@Override
		 
		public int getpassword(int userId, String pass) {

		 
		return bankRepository.changePassword(userId,pass);

		}



	@Override
	public List<Transactions> loadDateTransactions(String dateOfTransaction) {
		
		return bankRepository.loadDateTransactions( dateOfTransaction);
	}


	@Override
	public List<Transactions> loadMonthTransactions(String monthTransaction) {
		
		return bankRepository.loadMonthTransactions( monthTransaction);
	}


	@Override
	public List<Transactions> loadYearTransactions(String yearTransaction) {
		
		return bankRepository.loadYearTransactions(yearTransaction);
	}
	
	

@Override
 
public List<Transactions> loadMiniStatement(long accId) {
 

 
return bankRepository.loadMiniStatement(accId);

}

@Override
public List<Transactions> loadDetailedStatement(String startDate,String endDate,long accId) {

	 
return bankRepository.loadDetailedStatement(startDate,endDate,accId);

}

 
@Override
 
public int getservId(long accId) {
 

 
return bankRepository.getservId(accId);

}

@Override
 
public String getServiceTracker(int sid) {
 

 
return bankRepository.getServiceTracker( sid);

}


@Override
public int getCheckBook(long accId, String sd, String ss,String dt) {
	
	return bankRepository.getCheckBook(accId,  sd,  ss, dt) ;
}


@Override
public int add(UserTable usertable) {
	
	return bankRepository.add(usertable);
}

///Transactions
@Override
public boolean fundTransfer(long accno,long payeraccno, double amount,String paymtd) throws BankingException {
	
	return bankRepository.fundTransfer(accno,payeraccno, amount,paymtd);
}

@Override
public List<Payee> getAllUser(long accountId) throws BankingException {
	
	return bankRepository.getAllUser(accountId);
}


@Override
public boolean fundPayer(long accountId, double amount) throws BankingException {
	return	bankRepository.fundPayer(accountId,amount);
	
}

@Override
public boolean addPayee(Payee payee) throws BankingException {
	
	return bankRepository.addPayee(payee);
}

@Override
public boolean checkPayee(long paccId) throws BankingException {
	
	return bankRepository.checkPayee(paccId);
}



	

	
		
		
	

}
